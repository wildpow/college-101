import React from "react";
import Layout from "../components/layout";

const SatAct = () => (
  <Layout>
    <h1>SAT/ACT</h1>
  </Layout>
);

export default SatAct;
