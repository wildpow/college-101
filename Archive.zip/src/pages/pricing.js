import React from "react";
import Layout from "../components/layout";
// import Link from "gatsby-link";
import C2 from "../components/c2";

const HomeWorkHelp = () => (
  <Layout>
    <div>
      <C2 />
    </div>
  </Layout>
);

export default HomeWorkHelp;
