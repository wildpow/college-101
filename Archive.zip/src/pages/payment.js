import React from "react";
// import Link from "gatsby-link";
import Layout from "../components/layout";
import Checkout from "../components/checkout";

const Payment = () => (
  <Layout>
    <div>
      <Checkout />
    </div>
  </Layout>
);

export default Payment;
